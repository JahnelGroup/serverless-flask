



sls wsgi serve

sls deploy --force